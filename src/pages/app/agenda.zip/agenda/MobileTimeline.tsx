import { useEffect, useRef } from 'react';
import { format, addDays, startOfDay, isSameDay, isToday, addMinutes } from 'date-fns';
import { ptBR } from 'date-fns/locale/pt-BR';
import { Plus, ChevronLeft, ChevronRight, Clock, User } from 'lucide-react';
import { BOOKING_STATUS_CONFIG, type Booking } from '../../../hooks/useBookings';
import { useTheme } from '../../../contexts/ThemeContext';

interface Props {
  currentDay: Date;
  bookings: Booking[];
  onDayChange: (d: Date) => void;
  onBookingClick: (b: Booking) => void;
  onNewBooking: () => void;
}

const fmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });

export default function MobileTimeline({ currentDay, bookings, onDayChange, onBookingClick, onNewBooking }: Props) {
  const { theme } = useTheme();
  
  const days = Array.from({ length: 15 }, (_, i) => addDays(startOfDay(currentDay), i - 7));
  const activeDayRef = useRef<HTMLButtonElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeDayRef.current && containerRef.current) {
      const container = containerRef.current;
      const element = activeDayRef.current;
      
      // Calculate position to center the active element
      const containerWidth = container.clientWidth;
      const elementOffset = element.offsetLeft;
      const elementWidth = element.clientWidth;
      
      const scrollPosition = elementOffset - (containerWidth / 2) + (elementWidth / 2);
      
      container.scrollTo({ left: scrollPosition, behavior: 'smooth' });
    }
  }, [currentDay]);

  const dayBookings = bookings.filter(b => isSameDay(new Date(b.scheduled_at), currentDay));
  const sorted = [...dayBookings].sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());

  return (
    <div className="flex flex-col h-full pb-20 bg-transparent">
      {/* Premium Header Strip */}
      <div className="shrink-0 pt-4 pb-2 relative z-10 glass-card mx-2 mt-2 rounded-3xl mb-4 border" style={{ borderColor: 'transparent', boxShadow: '0 8px 32px rgba(0,0,0,0.05)' }}>
        {/* Month/Year and Nav */}
        <div className="flex items-center justify-between px-4 mb-4">
          <button onClick={() => onDayChange(addDays(currentDay, -1))} className="p-2 -ml-2 rounded-full transition-colors hover:bg-black/5" style={{ color: theme.textSecondary }}>
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <div className="text-center">
            <h2 className="font-serif text-xl font-bold capitalize tracking-tight" style={{ color: theme.textPrimary }}>
              {format(currentDay, 'MMMM yyyy', { locale: ptBR })}
            </h2>
            <p className="text-[11px] uppercase tracking-widest font-bold mt-0.5" style={{ color: theme.textSecondary }}>
              {isToday(currentDay) ? 'Hoje' : format(currentDay, 'EEEE', { locale: ptBR })}
            </p>
          </div>

          <button onClick={() => onDayChange(addDays(currentDay, 1))} className="p-2 -mr-2 rounded-full transition-colors hover:bg-black/5" style={{ color: theme.textSecondary }}>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Day Strip */}
        <div ref={containerRef} className="flex items-center gap-4 overflow-x-auto px-4 pb-4 scrollbar-none snap-x snap-mandatory relative pt-2">
          {days.map(day => {
            const selected = isSameDay(day, currentDay);
            const today = isToday(day);
            const hasBookings = bookings.some(b => isSameDay(new Date(b.scheduled_at), day));
            
            return (
              <button
                key={day.toISOString()}
                ref={selected ? activeDayRef : null}
                onClick={() => onDayChange(day)}
                className={`snap-center shrink-0 flex flex-col items-center justify-center w-[72px] h-[85px] rounded-[18px] transition-all relative ${
                  selected 
                    ? 'shadow-lg scale-105 z-10' 
                    : 'shadow-sm hover:shadow-md hover:-translate-y-0.5'
                }`}
                style={{
                  background: selected ? theme.accentGradient : theme.cardBg,
                  color: selected ? '#1a1a1a' : theme.textPrimary, // Force dark text on accent per user image
                  border: selected ? 'none' : `1px solid ${theme.border}`,
                }}
              >
                <span className="text-[10px] font-bold uppercase mb-1" style={{ color: selected ? 'rgba(0,0,0,0.6)' : theme.textSecondary }}>
                  {format(day, 'EEE', { locale: ptBR })}
                </span>
                <span className={`text-[26px] font-extrabold leading-none tracking-tight mb-1 ${selected ? 'text-black' : ''}`}>
                  {format(day, 'dd')}
                </span>
                <span className="text-[10px] font-bold uppercase" style={{ color: selected ? 'rgba(0,0,0,0.6)' : theme.textSecondary }}>
                  {format(day, 'MMM', { locale: ptBR })}
                </span>
                
                {/* Dot indicator for existing bookings */}
                {hasBookings && (
                  <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full shadow-sm" style={{ background: selected ? '#000' : theme.accent }} />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Timeline (Cards) */}
      <div className="flex-1 overflow-y-auto px-2 space-y-4">
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center pb-20">
            <div className="w-24 h-24 rounded-[2rem] border shadow-sm flex items-center justify-center mb-6 glass-card animate-fade-in" style={{ borderColor: 'transparent' }}>
              <Clock className="w-10 h-10 opacity-40" style={{ color: theme.textSecondary }} />
            </div>
            <p className="font-serif text-2xl font-bold mb-2 tracking-tight" style={{ color: theme.textPrimary }}>Dia Livre</p>
            <p className="text-sm max-w-[220px] leading-relaxed" style={{ color: theme.textSecondary }}>
              Nenhum agendamento marcado para esta data. Aproveite o descanso!
            </p>
            <button 
              onClick={onNewBooking}
              className="mt-8 px-8 py-3 rounded-2xl border-2 font-bold text-sm transition-all hover:scale-105"
              style={{ borderColor: theme.accent, color: theme.accent, background: 'transparent' }}
            >
              Criar Agendamento
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2 px-2">
              <span className="text-xs uppercase tracking-widest font-bold" style={{ color: theme.textSecondary }}>
                {sorted.length} {sorted.length === 1 ? 'Agendamento' : 'Agendamentos'}
              </span>
            </div>

            {sorted.map((b) => {
              const statusCfg = BOOKING_STATUS_CONFIG[b.status];
              const accent = b.pro_color || theme.accent;
              const start = new Date(b.scheduled_at);
              const end = addMinutes(start, b.duration_minutes);

              return (
                <div 
                  key={b.id} 
                  onClick={() => onBookingClick(b)}
                  className="rounded-3xl p-5 shadow-sm border active:scale-[0.98] transition-all overflow-hidden relative glass-card group cursor-pointer hover:shadow-md"
                  style={{ borderColor: 'transparent' }}
                >
                  {/* Subtle Glow Effect behind the card */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity" style={{ background: `linear-gradient(135deg, ${accent}, transparent)` }} />
                  
                  {/* Top: Time & Status */}
                  <div className="flex items-center justify-between mb-4 relative z-10">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl border shadow-sm" style={{ background: theme.cardBg, borderColor: theme.border }}>
                        <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: accent }} />
                        <span className="text-sm font-bold" style={{ color: theme.textPrimary }}>{format(start, 'HH:mm')}</span>
                      </div>
                      <span className="text-xs font-medium opacity-60" style={{ color: theme.textSecondary }}>até {format(end, 'HH:mm')}</span>
                    </div>
                    
                    <span className="px-3 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold shadow-sm" style={{ background: statusCfg.bg, color: statusCfg.color }}>
                      {statusCfg.label}
                    </span>
                  </div>

                  {/* Center: Service & Customer */}
                  <div className="mb-5 relative z-10">
                    <h3 className="font-serif text-xl font-bold mb-1 tracking-tight" style={{ color: theme.textPrimary }}>{b.customer?.name ?? 'Cliente'}</h3>
                    <p className="text-sm font-medium opacity-80" style={{ color: theme.textSecondary }}>{b.service?.name}</p>
                  </div>

                  {/* Bottom: Professional & Price */}
                  <div className="pt-4 border-t flex items-center justify-between relative z-10" style={{ borderColor: `color-mix(in srgb, ${theme.border} 40%, transparent)` }}>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center border shadow-sm" style={{ background: theme.cardBg, borderColor: theme.border }}>
                        <User className="w-3.5 h-3.5" style={{ color: theme.textSecondary }} />
                      </div>
                      <span className="text-sm font-bold" style={{ color: theme.textPrimary }}>{b.professional?.name ?? 'Sem profissional'}</span>
                    </div>
                    
                    <span className="text-base font-black" style={{ color: theme.textPrimary }}>{fmt.format(b.amount_total)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={onNewBooking}
        className="fixed bottom-24 right-6 w-14 h-14 rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.15)] flex items-center justify-center z-30 active:scale-95 transition-all hover:scale-105 border border-white/20"
        style={{ background: theme.accentGradient, color: theme.btnPrimaryText }}
      >
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
}

